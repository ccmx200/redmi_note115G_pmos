# evergo login welcome: distro-aware banner, fastfetch summary and the
# first-login wizard.  Sourced by /etc/profile for interactive shells.
#
# Nothing here may hardcode a distribution: the same overlay is used by the
# Arch, Debian, Ubuntu and Fedora images, and printing "Arch Linux ARM" on an
# Ubuntu login (which used to happen) is exactly what this file avoids.
case $- in *i*) ;; *) return 0 2>/dev/null || true ;; esac
[ -t 1 ] || return 0 2>/dev/null
[ -n "${EVERGO_WELCOMED:-}" ] && return 0 2>/dev/null
EVERGO_WELCOMED=1
export EVERGO_WELCOMED

# first login: create a user / set hostname / set root password
if [ ! -f /var/lib/evergo-first-login.done ] && [ -x /usr/local/bin/evergo-first-login ]; then
	/usr/local/bin/evergo-first-login
fi

# keep /etc/motd in sync (cheap; also fixes it after a distro upgrade)
[ -x /usr/local/bin/evergo-motd ] && /usr/local/bin/evergo-motd >/dev/null 2>&1

DIST=$(evergo-distro name 2>/dev/null || echo "Linux")
EMOJI=$(evergo-distro emoji 2>/dev/null || echo "🐧")
PKGCMD=$(evergo-distro pkgcmd 2>/dev/null || echo "?")

if [ -t 1 ] && [ "${TERM:-dumb}" != "dumb" ]; then
	B=$'\033[1m'; DIM=$'\033[2m'; R=$'\033[0m'
	CY=$'\033[1;36m'; MG=$'\033[1;35m'; GR=$'\033[1;32m'; YE=$'\033[1;33m'
else
	B=""; DIM=""; R=""; CY=""; MG=""; GR=""; YE=""
fi

spin() {
	# spin "message": draw a small braille spinner for ~0.4 s, then a check
	printf '  %s%s%s ' "$DIM" "$1" "$R"
	for f in ⠋ ⠙ ⠹ ⠸ ⠼ ⠴ ⠦ ⠧ ⠇ ⠏; do
		printf '\b%s' "$f"
		sleep 0.04 2>/dev/null || break
	done
	printf '\b%s✔%s\n' "$GR" "$R"
}

echo ""
echo "  ${CY}╭──────────────────────────────────────────────────────────╮${R}"
echo "  ${CY}│${R}  ${EMOJI} ${B}evergo${R}  ·  ${MG}${DIST}${R}  ·  Redmi Note 11T 5G"
echo "  ${CY}│${R}  ${DIM}MediaTek MT6833  ·  mainline Linux${R}"
echo "  ${CY}╰──────────────────────────────────────────────────────────╯${R}"
spin "正在加载系统信息…"

if command -v fastfetch >/dev/null 2>&1; then
	fastfetch -c /etc/evergo/fastfetch.jsonc 2>/dev/null || true
fi

# the one thing fastfetch cannot show: how usb0 is addressed right now
MODE=$(evergo-mode status 2>/dev/null | head -1 | sed 's/.*MODE: *//')
[ -z "$MODE" ] && MODE="unknown"
IPADDR=$(ip -4 -br addr show usb0 2>/dev/null | awk '{print $3}')
[ -z "$IPADDR" ] && IPADDR="-"

printf '  %s🌐 %-8s%s %s   %s%s%s\n' "$CY" "network" "$R" "$MODE" "$DIM" "$IPADDR" "$R"
printf '  %s🔁 %-8s%s %s\n' "$CY" "switch" "$R" "evergo-mode pc | evergo-mode router | evergo-mode status"
printf '  %s📊 %-8s%s %s\n' "$CY" "system" "$R" "evergo-info"
printf '  %s📦 %-8s%s %s\n' "$CY" "packages" "$R" "$PKGCMD"
echo ""

# If a crash/reboot happened while the screen was switched off, the power-key
# daemon may have left gsd's ambient brightness disabled; restore it for the
# normal "screen on" state (the daemon itself does the same on wake).
if command -v gsettings >/dev/null 2>&1 && [ "$(cat /run/evergo-powerkey.state 2>/dev/null)" != "off" ]; then
	gsettings set org.gnome.settings-daemon.plugins.power ambient-enabled true 2>/dev/null || true
fi
