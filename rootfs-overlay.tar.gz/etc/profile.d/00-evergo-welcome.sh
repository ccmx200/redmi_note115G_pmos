# evergo login welcome: fastfetch summary plus the first-login wizard.
# Sourced by /etc/profile for interactive bash/sh logins.
case $- in *i*) ;; *) return 0 2>/dev/null || true ;; esac
[ -t 1 ] || return 0 2>/dev/null
[ -n "${EVERGO_WELCOMED:-}" ] && return 0 2>/dev/null
EVERGO_WELCOMED=1
export EVERGO_WELCOMED

# first login: create a user / set hostname / set root password
if [ ! -f /var/lib/evergo-first-login.done ] && [ -x /usr/local/bin/evergo-first-login ]; then
    /usr/local/bin/evergo-first-login
fi

echo ""
if command -v fastfetch >/dev/null 2>&1; then
    fastfetch -c /etc/evergo/fastfetch.jsonc 2>/dev/null || fastfetch 2>/dev/null || true
else
    printf '  Arch Linux ARM on evergo\n'
fi

# the one thing fastfetch cannot show: how usb0 is addressed right now
MODE=$(evergo-mode status 2>/dev/null | head -1 | sed 's/.*MODE: *//')
[ -z "$MODE" ] && MODE="unknown"
printf '  %-12s %s\n' "network" "$MODE   $(ip -4 -br addr show usb0 2>/dev/null | awk '{print $3}')"
printf '  %-12s %s\n' "switch" "evergo-mode pc | evergo-mode router | evergo-mode status"
printf '  %-12s %s\n' "system" "evergo-info"
echo ""
